using TrainControl.Contracts.Messages;
using System.Net.Sockets;
using System.Net;
using System.Text.Json;
using TrackController.Contracts.Messages;
using TrackController.Core.Models;
using TrackController.Core.Services;
using TrainControl.Common.Communication;

namespace TrackController.Runtime;

/// <summary>PC-side client that sends inputs to the Pi and receives its results. A broken or expired connection produces stop/unknown outputs.</summary>
public sealed class PiWaysideRuntime : IWaysideRuntime
{
    private readonly string _host;
    private readonly int _port;
    private readonly WaysideConfigurationMessage _configuration;
    private readonly SemaphoreSlim _io = new(1, 1);
    private readonly CancellationTokenSource _stop = new();
    private string _programName, _programSource;
    private TcpClient? _socket;
    private PiProtocol? _protocol;
    private TimeSpan _clockOffset;
    private DateTimeOffset _retryAfter;
    private bool _disposed;
    private bool _maintenanceRequested;

    public WaysideSnapshotMessage LatestSnapshot { get; private set; }

    /// <summary>Configures the direct Pi or optional SSH-tunnel endpoint and the territory used for a new Pi session.</summary>
    public PiWaysideRuntime(string host, int port, WaysideConfigurationMessage configuration, string programName, string programSource, bool maintenanceMode = false)
    {
        if (!IPAddress.TryParse(host, out var address) || address.Equals(IPAddress.Any) || address.Equals(IPAddress.IPv6Any) || port is < 1 or > 65535)
        {
            throw new ArgumentException("Use the Pi IP address and a port from 1 to 65535, or a loopback IP for local testing.");
        }

        _host = host;
        _port = port;
        _configuration = WaysideConfiguration.ValidateAndCopy(configuration);
        _programName = programName;
        _programSource = programSource;
        _maintenanceRequested = maintenanceMode;
        LatestSnapshot = new TrackControllerService(_configuration).GetSnapshot().CreateStopSnapshot("Pi not connected. Start the Pi runtime and check its IP address and port.");
    }

    /// <summary>Handles an application message through the selected runtime and returns its result.</summary>
    public async Task<object> ReceiveAsync(MessageEnvelope message, CancellationToken cancellationToken = default)
    {
        await _io.WaitAsync(cancellationToken);
        try
        {
            if (_disposed)
            {
                throw new ObjectDisposedException(nameof(PiWaysideRuntime));
            }

            // Preserve servicing intent even if the connection fails before its acknowledgement.
            if (message.MessageType == "SetMaintenanceMode")
                _maintenanceRequested = MessageSerializer.ReadValue<bool>(message, "enabled");
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken, _stop.Token);
            timeout.CancelAfter(1500);
            if (message.MessageType == "LoadPlc")
            {
                if (_configuration.AutomaticOperation && !_maintenanceRequested)
                    return new WaysideAcknowledgementMessage(false, "Enter maintenance mode before replacing the PLC.", message.MessageType);
                // Preserve the requested replacement even if receipt is lost or compilation fails.
                // Reconnection must never silently restore an older, permissive program.
                string? territoryId = message.Payload.TryGetProperty("territoryId", out var targetId) ? targetId.GetString() : null;
                if (territoryId is not null && territoryId != _configuration.WaysideId)
                {
                    return new WaysideAcknowledgementMessage(false, "PLC target does not match this territory.", message.MessageType);
                }
                var name = MessageSerializer.ReadValue<string>(message, "name");
                var source = MessageSerializer.ReadValue<string>(message, "source");
                _programName = name;
                _programSource = source;
            }

            await ConnectAsync(timeout.Token);
            if (message.MessageType == "TrackModelBlockStates")
            {
                var feedback = MessageSerializer.ReadValue<List<TrackModelBlockStateMessage>>(message, "blocks");
                foreach (var block in feedback)
                {
                    block.ObservedAtUtc += _clockOffset;
                }

                message = MessageSerializer.CreateEnvelope("TrackModelBlockStates", new { blocks = feedback });
            }

            if (message.MessageType == nameof(TrackModelBlockStateMessage))
            {
                var block = MessageSerializer.DeserializePayload<TrackModelBlockStateMessage>(message);
                block.ObservedAtUtc += _clockOffset;
                message = MessageSerializer.CreateEnvelope(nameof(TrackModelBlockStateMessage), block);
            }

            var sentAt = DateTimeOffset.UtcNow;
            await _protocol!.WriteAsync(message, timeout.Token);
            var envelope = await _protocol.ReadAsync(timeout.Token);
            if (envelope.MessageType == nameof(WaysideSnapshotMessage))
            {
                var snapshot = MessageSerializer.DeserializePayload<WaysideSnapshotMessage>(envelope);
                if (snapshot.Blocks is null || snapshot.Blocks.Any(blockStatus => blockStatus is null) || snapshot.WaysideId != _configuration.WaysideId || !snapshot.Blocks.Select(blockStatus => blockStatus.BlockId).Order().SequenceEqual(WaysideConfiguration.GetOwnedIds(_configuration).Order()) || snapshot.NeighborObservations is null || snapshot.NeighborObservations.Any(neighbor => neighbor is null) || !snapshot.NeighborObservations.Select(neighbor => neighbor.BlockId).Order().SequenceEqual(WaysideConfiguration.GetNeighborIds(_configuration).Order()))
                {
                    throw new InvalidDataException("Pi returned a different territory.");
                }

                var evaluated = snapshot.EvaluatedAtUtc - _clockOffset;
                var validUntil = snapshot.ValidUntilUtc - _clockOffset;
                // Never extend a lease by network/queue delay, even if host clocks differ.
                var conservativeLimit = sentAt + (snapshot.ValidUntilUtc - snapshot.EvaluatedAtUtc);
                if (validUntil > conservativeLimit)
                {
                    validUntil = conservativeLimit;
                }

                if (validUntil <= DateTimeOffset.UtcNow || validUntil > sentAt.AddSeconds(1.5))
                {
                    throw new InvalidDataException("Pi output expired before receipt.");
                }

                LatestSnapshot = snapshot with
                {
                    EvaluatedAtUtc = evaluated,
                    ValidUntilUtc = validUntil
                };
                return LatestSnapshot;
            }

            if (envelope.MessageType != nameof(WaysideAcknowledgementMessage))
            {
                throw new InvalidDataException("Unexpected Pi response.");
            }

            var result = MessageSerializer.DeserializePayload<WaysideAcknowledgementMessage>(envelope);
            return result;
        }
        catch (Exception ex) when (ex is IOException or InvalidDataException or SocketException or JsonException or OperationCanceledException or ArgumentException or InvalidOperationException)
        {
            DropConnection();
            if (DateTimeOffset.UtcNow >= _retryAfter)
            {
                _retryAfter = DateTimeOffset.UtcNow.AddSeconds(1);
            }

            LatestSnapshot = LatestSnapshot.CreateStopSnapshot($"Pi unavailable: {ex.Message}");
            if (cancellationToken.IsCancellationRequested)
            {
                throw;
            }

            return new WaysideAcknowledgementMessage(false, LatestSnapshot.PlcStatus, message.MessageType);
        }
        finally
        {
            _io.Release();
        }
    }

    /// <summary>Refreshes runtime outputs so timeouts apply even when no new input arrives.</summary>
    public async Task<WaysideSnapshotMessage> PollAsync(CancellationToken cancellationToken = default)
    {
        await ReceiveAsync(MessageSerializer.CreateEnvelope("GetSnapshot", new { }), cancellationToken);
        return LatestSnapshot;
    }

    private async Task ConnectAsync(CancellationToken cancellationToken)
    {
        if (_protocol is not null)
        {
            return;
        }

        if (DateTimeOffset.UtcNow < _retryAfter)
        {
            throw new IOException("Waiting to reconnect to the Pi.");
        }

        _socket = new TcpClient
        {
            NoDelay = true
        };
        var before = DateTimeOffset.UtcNow;
        await _socket.ConnectAsync(_host, _port, cancellationToken);
        _protocol = new(_socket.GetStream());
        var helloEnvelope = await _protocol.ReadAsync(cancellationToken);
        if (helloEnvelope.MessageType == nameof(WaysideAcknowledgementMessage))
        {
            throw new IOException(MessageSerializer.DeserializePayload<WaysideAcknowledgementMessage>(helloEnvelope).Detail);
        }

        if (helloEnvelope.MessageType != nameof(PiHello))
        {
            throw new InvalidDataException("Not a Track Controller Pi endpoint.");
        }

        var hello = MessageSerializer.DeserializePayload<PiHello>(helloEnvelope);
        if (hello.Version != PiProtocol.Version)
        {
            throw new InvalidDataException("Pi protocol version mismatch. Deploy the matching runtime.");
        }

        _clockOffset = hello.ServerTimeUtc - (before + (DateTimeOffset.UtcNow - before) / 2);
        await _protocol.WriteAsync(new PiSessionStart(_configuration, _programName, _programSource, _maintenanceRequested), cancellationToken);
        var response = await _protocol.ReadAsync(cancellationToken);
        if (response.MessageType != nameof(WaysideAcknowledgementMessage))
        {
            throw new InvalidDataException("Missing Pi initialization response.");
        }

        var receipt = MessageSerializer.DeserializePayload<WaysideAcknowledgementMessage>(response);
        if (!receipt.IsAccepted)
        {
            throw new IOException(receipt.Detail);
        }
    }

    private void DropConnection()
    {
        _socket?.Dispose();
        _socket = null;
        _protocol?.Dispose();
        _protocol = null;
    }

    /// <summary>Stops owned background operations and releases connections before returning.</summary>
    public async ValueTask DisposeAsync()
    {
        if (_disposed)
        {
            return;
        }

        _disposed = true;
        await _stop.CancelAsync();
        await _io.WaitAsync();
        try
        {
            DropConnection();
        }
        finally
        {
            _io.Release();
        }
    }
}
