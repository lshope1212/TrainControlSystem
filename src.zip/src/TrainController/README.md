# Train Controller module

Controls ten trains. The Software/Hardware assignment is **fixed** (defined only in
`TrainController.Abstractions/Fleet/TrainFleet.cs`; no runtime switching, no fallback):

| Controller | Trains                                              | Runs on                   |
| ---------- | --------------------------------------------------- | ------------------------- |
| Software   | TRAIN-001, TRAIN-003, TRAIN-005, TRAIN-007, TRAIN-009 | Windows host (in-process) |
| Hardware   | TRAIN-002, TRAIN-004, TRAIN-006, TRAIN-008, TRAIN-010 | one Raspberry Pi (TCP/IP) |

## Projects

| Project                          | Target           | Responsibility |
| -------------------------------- | ---------------- | -------------- |
| `TrainController.Abstractions`   | `net10.0`        | Internal data model: fleet + fixed assignment, `TrainControllerInput`/`Output`, vehicle specification, provisional policy values, input/output validation. No control law. |
| `TrainController.Core`           | `net10.0`        | **Software** Train Controller control law (one independent controller state per train). |
| `TrainController.Integration`    | `net10.0`        | Routing, per-train state registry, Test Mode / Test Simulation control, backends (Software adapter, Hardware TCP client), framing, Named Pipe adapters, output routing. No control law, no WPF. |
| `TrainController.Hardware.Pi`    | `net10.0` console | **Hardware** Train Controller: independent process on the Raspberry Pi (TCP server). Must not reference `TrainController.Core` (enforced by `TrainControllerArchitectureTests`). |
| `TrainController.Wpf`            | `net10.0-windows` | Main UI (Driver/Engineer) and Test UI (Train Model stand-in). Views and ViewModels only. |

Dependency direction:

```
TrainController.Wpf ──► TrainController.Integration ──► TrainController.Core ──► TrainController.Abstractions ──► Contracts / Common
                                                    └──────────────────────────► TrainController.Abstractions
TrainController.Hardware.Pi ─────────────────────────────────────────────────► TrainController.Abstractions ──► Contracts / Common
```

## Publishing the Raspberry Pi controller

For 64-bit Raspberry Pi OS, from the repository root:

```
dotnet publish src/TrainController/TrainController.Hardware.Pi -c Release -r linux-arm64 --self-contained true -p:PublishReadyToRun=true -o publish/pi
```

(Full Pi deployment instructions are added with the Pi server phase.)

## Conventions specific to this module

- **Two peer-level windows.** Unlike the other modules, `TrainController.Wpf` has a Main UI
  window and a Test UI window. Neither is a child of the other. This is an intentional,
  documented exception to the repository's one-window convention, because the Test UI
  must control the Train Controller's own test simulation (Run/Stop/Step/Reset/Speed).
- **Test Mode is global.** Either every train takes its model input from the real Train
  Model, or every train takes it from its Test UI test state. Never mixed, never both.
- **Running is owned by the system.** A train executes controller ticks only while its
  model input reports `IsActive` (dispatched via CTC → Track Controller → Train Model; in
  Test Mode, set in that train's Test Model state). The Train Controller has no start/stop
  toggle of its own, and no train runs by default.
- **SI internally, imperial in the UI.** Conversions use `TrainControl.Common.Utilities.UnitConversion`.
- **IPC.** Windows-to-Windows module communication will use the repository's existing
  named-pipe + JSON envelope transport behind adapters. TCP/IP is used **only** between the
  Windows Hardware backend (client) and the Raspberry Pi (server).

## Beacon reception

The requirement is that **every newly received valid beacon recalibrates the distance to the
next station**; between receptions the controller dead-reckons from actual speed × dt.
Internally each tick's `BeaconData.IsNewlyReceived` marks a reception. It is set by the
model-input provider, not imposed on the Train Model contract:

- Test Mode: the Test UI's "transmit beacon" action marks one reception, consumed by that
  train's next tick.
- Normal Mode: the Train Model interface does not yet define how a reception is signalled;
  the Normal-Mode adapter will derive `IsNewlyReceived` once that mechanism is agreed.

## Fail-safe output

Used for Hardware communication failure and any invalid input/output or controller
exception (`FailSafeOutput`): power 0 and emergency brake applied. Door commands are never
carried over; doors stay subject to the door/motion interlock — a door may remain open only
if the last known Train Model state shows the train stopped and that door already open;
otherwise both sides are commanded closed. The fail-safe never opens a door. Exterior lights
and cabin setpoint are retained.

## Runtime structure (Integration)

```
TrainControllerSubsystem (composition root, one per process)
 ├─ TrainStateRegistry ── 10 × TrainRuntimeSlot (Driver, Engineer, TestModel, last output)
 ├─ TestModeController ── GLOBAL switch: NormalModelInputProvider | TestModelInputProvider
 ├─ TrainControllerTickEngine
 │     per tick, for every ACTIVE train:
 │       model input (current provider) + Driver + Engineer + timing -> TrainControllerInput
 │       -> TrainControllerExecutionService (validate, route, fail-safe, log)
 │            -> TrainControllerRouter -> SoftwareTrainControllerBackend | Hardware backend
 │       -> OutputRouter (record for UIs; Normal Mode only: send to Train Model sink)
 └─ TestSimulationController (Run / Stop / Step / Reset / Speed; Test Mode only)
```

- **Fixed simulated dt.** Every tick uses `SimulationTimeStepSeconds`; simulation time is
  TickId × dt. The speed multiplier only shortens the wall-clock interval between ticks
  (dt / multiplier).
- **Stop** lets the current tick finish, then freezes; nothing is lost. **Reset** stops, then
  clears tick counter, simulation time, every controller's runtime (PI integral, E-brake
  latch, station tracking, dwell), previous outputs and pending one-shot events for all ten
  trains. Engineer Kp/Ki, vehicle data, Driver held settings and Test Model input values stay.
- **Normal Mode ticking** is not driven yet: the Test Simulation controls are Test-Mode only,
  and the Normal-Mode tick source (shared system clock / Train Model updates) is a future
  integration point that will call `TrainControllerTickEngine.ExecuteTickAsync`.
- Until the Raspberry Pi backend exists, `NotConnectedHardwareBackend` makes every Hardware
  train fail safe (power 0, emergency brake). There is no Software fallback.

## User interfaces (TrainController.Wpf)

Two PEER windows open at startup on the same `TrainControllerSubsystem`; the app exits when
both are closed. Visual style follows the team's CTC Office / Track Model wireframes (dark
navy header, white panels with gray header bands, label/value status cards, flat buttons,
green/red/orange/blue status colors).

| Window | Contains | Never contains |
| ------ | -------- | -------------- |
| **Main UI** (`MainWindow`) | Header: train dropdown (TRAIN-001…010 with fixed SW/HW label), controller source badge, input-source badge, simulation time. Guidance panel: traffic-light signal head (red / yellow / green lamp lit, all dark = unknown; display only) with a SIGNAL lamp below it (green = track signal valid, red = invalid), and the distance bar (station brake point, authority brake point, authority end, station — labelled vertical lines, no separate legend). Alert banner below it: the single most important ongoing condition (fail-safe > emergency brake > failure > signal lost > authority protection > overspeed > doors open) with what to do; hidden when none. Speed panel: actual / setpoint (and what limits it) / commanded / driver request / power, then FAILURES: SIGNAL PICKUP, BRAKE, ENGINE (+ PI LINK on Hardware trains) red lamps (dark = OK), reset availability, a full-width RESET FAILURES button and, for ~4 s, why a reset was rejected. Driver Controls: mode (default Automatic); requested speed (Manual only, empty = follow the commanded speed, Set / Clear); service brake / EMERGENCY BRAKE / E-brake reset, each brake with a lamp showing the brake actually commanded; doors and exterior lights as toggles whose lamp shows the real state reported by the Train Model (pressed = driver request, lamp = actual); announcement with the last one sent; cabin °F setpoint with the actual temperature. Right column: Status (Pi link, fault, emergency causes, E-brake reset guidance) and Engineer Kp/Ki with the untuned-gains warning. Bottom: fleet table and event log. Layout sizes are proportional (bottom area and right column scale with the window) so it fits different screen sizes / Windows scaling | Train Model inputs, simulation controls |
| **Test UI** (`TestWindow`) | Own train dropdown (independent of the Main UI), GLOBAL input source (Train Model / Test UI), Run / Stop / Step / Reset / speed, "Simple physics" (test tool: speed, doors and lights follow the commands; off = hold the speed by hand to reproduce failures), Train Model → Train Controller inputs (incl. commanded speed and traffic light) of the selected train (incl. "active / dispatched" = Train Model state, and "Transmit beacon"), Train Controller → Train Model outputs, fleet table limited to Train Model boundary I/O, edge-value warnings | Driver or Engineer controls, controller type, any non-boundary data (enforced by tests) |

**UI units are imperial everywhere: mph, ft, °F, hp** (480 000 W ≈ 644 hp). Internal,
integration and Pi values stay SI (m/s, m, °C, W, s). Conversion happens only in
`Integration/Presentation` (`DisplayUnits`, `RequestedSpeedEntry`) via
`TrainControl.Common.Utilities.UnitConversion`. Kp/Ki are labelled with their SI meaning
(W per m/s, W per m) because they are gains, not displayed quantities; converting them would
change their meaning for both controllers.

**Window lifetime:** both windows share one subsystem; `ShutdownMode=OnLastWindowClose`, so
closing one window leaves the other (and the running subsystem) untouched. Each window's
selected train is independent and never affects which trains run.

Layering and restyling:

- **All colors and styles** are in `TrainController.Wpf/Resources/Theme.xaml`. View models
  expose semantic `DisplayTone`s (Neutral / Muted / Good / Info / Warning / Danger), never colors.
- **Display formatting and imperial units** are produced by
  `TrainController.Integration/Presentation` (`DisplayUnits`, `TrainControllerPresenter`) —
  framework-neutral and unit-tested. View models only bind and forward edits.
- View models refresh by polling (100 ms, display only). Editable fields are reloaded only
  when the selected train changes, so typing is never overwritten. Selecting a train never
  starts, stops or resets any train.
- Reusable view pieces: `Views/Controls/KeyValueRow` (status row) and
  `Views/Controls/GuidanceBar` (distance bar, drawn to scale from controller output; position 0 = train front,
  the TRAIN icon is drawn entirely behind it; every marker is a vertical line at its exact position).

## Software Train Controller behavior (TrainController.Core)

`SoftwareTrainController` — one instance per Software train — executes per tick:

1. Input validation (invalid → fail-safe).
2. Tracking (station-relative, not absolute position):
   - **Station distance**: each newly received valid beacon recalibrates; otherwise
     distance −= v·dt (signed). Arrival = |distance| ≤ threshold AND stopped. The station
     target is cleared (icon removed, "waiting for next beacon") when the train departs a
     served station, or goes past it by more than the threshold without stopping.
   - **Remaining authority**: received values are trusted ONLY while `TrackSignalValid` is
     true. With a valid signal the estimate is initialized from the first received value and
     recalibrated on each new authority update (`TrainModelInput.AuthorityUpdateReceived`).
     With an invalid signal, received authority values are ignored and the last trusted
     estimate keeps decreasing by v·dt (clamped at 0); restoring the signal does not by itself
     recalibrate — the next valid-signal update does. With no trusted value yet and an invalid
     signal, remaining authority is 0 (no movement permitted). Authority protection, the
     authority braking curve and the display all use this estimate. In the Test UI, changing
     Remaining authority (or "Send authority") is an authority update.

### Terminology

- **Actual speed** — measured speed reported by the Train Model.
- **Commanded speed** — wayside speed received through the track (formerly "authorized speed").
  Trusted only while the track signal is valid.
- **Setpoint speed** — the controller's final speed target after all limits (formerly
  "effective target").
- **Authority** — remaining permitted travel DISTANCE (not a speed).

### Signal pickup (`TrackSignalValid`) and traffic light

Signal pickup is the existing `TrackSignalValid` input (Train Model → controller; Test UI
"Track signal valid"). There is no `SignalPickupFailure` input. As soon as the signal is
invalid: setpoint 0, power 0, service brake, and newly received commanded speed / authority
are not trusted. Invalid for `SignalPickupFailureLatchSeconds` (0.5 s = 5 ticks) in a row →
**Signal Pickup Failure** latched (see Failure detection).

The **traffic light** (`TrainModelInput.TrafficLight`, shared `SignalState`: Unknown / Red /
Yellow / Green — the enum the Track Model already uses) is DISPLAY-ONLY: no control logic uses
it yet, and it is a separate concept from `TrackSignalValid`. Its field in
`TrainModelStatusMessage` is provisional until the final Track Model contract is agreed.

### Failure detection (inferred, latched)

`TrainController.Core/Safety/FailureMonitor.cs` (Pi: `HardwareTrainController.FailureWatch`)
infers failures from normal observable data only — no Train Model failure flags. The speed
measured on a tick is judged against the commands of the PREVIOUS tick. All thresholds are in
`ControllerPolicy`.

| Failure | Detected when | Response | "Reset failures" accepted when |
| ------- | ------------- | -------- | ------------------------------ |
| Signal pickup | `TrackSignalValid == false` for 0.5 s in a row | setpoint 0, power 0, service brake (from the first invalid tick) | track signal valid |
| Brake (service brake only; the emergency brake is assumed to work) | service brake commanded, no emergency brake, speed > 1.0 m/s, for 1.0 s, average deceleration < 0.3 m/s² | power 0, **emergency brake** | train stopped |
| Engine | no brake, setpoint − speed > 0.5 m/s, power ≥ 10 % of 480 kW, for 1.0 s, average acceleration ≤ 0 | power 0, **service brake** (a failing service brake then triggers Brake Failure → emergency brake) | train stopped |
| Hardware link (Hardware trains, integration layer) | any Pi communication fault | fail-safe (power 0, emergency brake) | Pi link healthy again; the Pi state of that train is re-synchronized |

All failures are latched; a rejected reset leaves that failure latched and is shown and
logged with the reason. When a Brake Failure is detected while the driver is holding the
service brake (Manual testing), the integration layer releases that now-ineffective request
(logged), so after "Reset failures" the train is not left braked by a forgotten toggle — the
same outcome as in Automatic. Failure detected / cleared / reset rejected are written to the event
log (category `Safety`). Engine failure needs the controller to demand at least 48 kW: while
cruising very little power is needed, so a dead engine is detected quickly only while the train
is accelerating (Ki makes the power rise when the speed keeps falling).

Testing failures in the Test UI: turn **Simple physics** off only while provoking a failure
(hold the actual speed by hand). Turn it back on before "Reset failures": with physics off the
speed cannot rise, so a train that is powered after the reset is — correctly — detected as an
Engine Failure again.

### Emergency brake — how each cause is released

| Cause | Released by |
| ----- | ----------- |
| Driver press, passenger request | **E-brake reset** — only when stopped and no passenger request is active |
| Brake failure, Hardware link failure | **Reset failures** |
| Authority (cannot stop within authority, incl. no trusted authority while the signal is invalid) | automatically on the first tick the train is stopped (authority limit / holding brake keep it there) |

The E-brake reset, "Reset failures" and the Test UI Reset are three separate actions.

3. Setpoint speed = MINIMUM of: commanded speed, vehicle maximum, the remaining-authority
   braking curve √(2·1.2·(authority − margin)), the driver request (Manual, only when set —
   no request = follow the commanded speed), and in BOTH modes the station braking curve
   √(2·1.2·(station distance − margin)) / station stop. 0 while the track signal is invalid
   or a signal-pickup failure is latched, while a brake / engine failure is latched, while the
   emergency brake is applied, or while the driver holds the service brake
   (`DriverServiceBrake`; the requested speed setting is kept and applies again on release). The binding constraint is reported as the strongly typed `TargetLimitedBy`
   (`TargetSpeedConstraint`); presentation converts it to text. The driver request can only
   LOWER the target; Automatic mode never uses it. Manual differs from Automatic ONLY by this
   optional request. The station braking curve applies only
   when a valid next-station distance exists (`StationTracker.HasValidDistance`); missing or
   invalid station information never implies a zero target. The authority braking curve is
   a PREVENTIVE target limit; `AuthorityProtection` (step 4) remains the INDEPENDENT safety
   backstop — neither replaces the other.
4. Authority protection: service brake when authority ≤ service stopping distance + authority
   margin + v·dt; emergency brake when authority < emergency stopping distance while moving;
   service-brake hold when stopped with exhausted authority.
5. Emergency brake: see "Emergency brake — how each cause is released" above.
6. Station guidance: latest brake point = distance − v·dt − (v²/2·1.2 + station margin).
   Authority brake point (display only, same thresholds as authority protection) = remaining authority − v·dt − (v²/2·1.2 + authority margin); stopped: remaining authority − margin. ≤ 0 ⇔ authority protection applies the service brake.
   Both modes: the controller applies the service brake itself (no driver action needed).
7. Arrival = distance ≤ station threshold AND speed ≤ stopped threshold. Both modes: dwell
   with platform-side doors open, then close and depart.
8. Doors: the dwell opens the platform side; the driver may also open either side while
   stopped, in either mode (e.g. emergencies). Closed and requests refused while moving;
   traction inhibited while any door is open or commanded open.
9. Overspeed (> limit): service brake.
10. PI power (Kp·e + Ki·∫e dt, SI, clamped to 0 … 480 kW, anti-windup, integral cleared while
    traction is inhibited) only when no brake is applied, doors are closed and no failure is latched.

### Station announcements

`TrainModelCommand.StationAnnouncement` is an EVENT: non-empty on exactly one tick.

- Automatic: once when a newly received valid beacon names the next station
  ("Next station: X. Doors will open on the left/right/both sides."), and once on arrival
  ("Arrived at X."). If both happen on the same tick, the arrival is announced.
- Driver (Main UI, Manual or Automatic): one-shot text sent on the train's next tick; it takes
  precedence over an automatic announcement on that tick.
- Because the command lasts one tick, the Windows side keeps the last announcement sent
  (`TrainRuntimeSlot.LastAnnouncement`, display only) so both UIs can show it.

Wording of the automatic announcements is provisional.

### Diagnostics shown to the driver

- `TractionState` (shown as **Power status** in the Main UI) explains a zero power command (at/above target, holding brake while
  stopped, service brake, door interlock, emergency brake, fail-safe).
- `EmergencyBrakeResetBlockedReason` says whether a driver reset is possible right now and,
  if not, why (passenger request active, cannot stop within authority, signal lost).
- `StationEvent` reports Arrived / Departed / PassedWithoutStopping.

**Testing without a Train Model:** the Test UI has no physics, so Actual speed only changes
when the tester edits it. With authority now counted down by v·dt, a train left running at
constant speed WILL eventually reach authority protection and then the emergency brake —
this is correct controller behavior. Lower Actual speed (simulating the train braking) or
send a new authority.

## Hardware Train Controller (Raspberry Pi)

```
Windows: TrainControllerTickEngine
   -> TrainControllerExecutionService -> TrainControllerRouter
   -> TcpHardwareTrainControllerBackend  (transport + validation only, no control law)
        FIFO request lock -> one long-lived TCP connection -> [4-byte length][JSON]
Pi:  HardwareControllerServer -> HardwareRequestHandler
        -> HardwareTrainController[TRAIN-002 / 004 / 006 / 008 / 010]  (independent state each)
```

- **Protocol** (`Abstractions/Hardware/HardwareProtocol.cs`, version 1): JSON
  `HardwareEnvelope` per length-prefixed frame (`Common/Communication/LengthPrefixedFraming.cs`).
  Hello / HelloResponse on connect (version + served trains), ControllerRequest (complete SI
  `TrainControllerInput`) / ControllerResponse (`TrainControllerOutput`), ResetRequest /
  ResetResponse, ErrorResponse. Every reply echoes ProtocolVersion, RequestId, TrainId, TickId;
  NaN / Infinity cannot be encoded.
- **Synchronous semantics, async I/O**: tick N in → tick N out, using async socket I/O; the UI
  thread never blocks. Requests from the five trains are serialized FIFO (deterministic).
- **Cold start**: both ends warm up serialization (the Pi also its handler/controller) at
  start-up; the handshake and the first controller request on each connection use the connect
  timeout, later requests the strict request timeout. The Pi is published ReadyToRun.
- **Failures** — refused, dropped, timeout, invalid framing, malformed JSON, wrong version /
  train / tick / request id (stale or duplicate), wrong message type, Pi error, invalid numbers:
  the connection is closed, the train gets a fail-safe output (power 0, emergency brake), the
  Main UI shows Faulted. No Software fallback, ever.
- **Link-fault latch** (integration safety policy, provisional): after a fault the train stays
  in fail-safe (Hardware link failure) until the link works AND the driver presses
  "Reset failures"; the Pi state of that
  train is then reset (its estimates did not advance during the outage, so station distance is
  re-learned from the next beacon). Other Hardware trains are unaffected.
- **Test Simulation Reset** also resets all Pi train states (queued until reconnect if the Pi is
  unreachable).
- **Equivalence**: `SoftwareHardwareEquivalenceTests` feeds identical input vectors to both
  controllers (in-process and over loopback TCP) and compares every command and display field.
- Configuration: `TrainController.Wpf/appsettings.json` (`HardwareLink`), Pi command line.
  Deployment: `TrainController.Hardware.Pi/README.md`.

## Provisional configuration defaults

The values below are **not** defined by any project source. They are placeholders so the
system can run, kept in named configuration, and must be replaced when defined. They are not
requirements. (Source-backed vehicle data lives separately in `VehicleSpecification`.)

| Setting | Location | Provisional default |
| ------- | -------- | ------------------- |
| Stopped-speed threshold | `ControllerPolicy.StoppedSpeedThresholdMetersPerSecond` | 0.1 m/s |
| Station arrival distance threshold | `ControllerPolicy.StationDistanceThresholdMeters` | 2.0 m |
| Station braking margin | `ControllerPolicy.StationBrakingMarginMeters` | 0 m (none invented) |
| Authority braking margin | `ControllerPolicy.AuthorityBrakingMarginMeters` | 0 m (none invented) |
| Station dwell time | `ControllerPolicy.StationDwellTimeSeconds` | 30 s |
| Initial Manual/Automatic mode | `ControllerStartupDefaults.InitialOperatingMode` | Automatic (team decision) |
| Signal pickup failure latch | `ControllerPolicy.SignalPickupFailureLatchSeconds` | 0.5 s |
| Brake failure: minimum speed / window / minimum deceleration | `ControllerPolicy.BrakeFailure*` | 1.0 m/s / 1.0 s / 0.3 m/s² |
| Engine failure: minimum speed error / minimum power / window / maximum acceleration | `ControllerPolicy.EngineFailure*` | 0.5 m/s / 10 % of rated power / 1.0 s / 0 m/s² |
| Test UI simple physics | `TestModeController.SetSimplePhysics` (WPF turns it on) | on in the app, off in code |
| Initial driver cabin setpoint | `ControllerStartupDefaults.InitialCabinTemperatureSetpointCelsius` | 21 °C (≈ 70 °F) |
| Initial Test Model cabin temperature | `ControllerStartupDefaults.InitialTestCabinTemperatureCelsius` | 21 °C (≈ 70 °F) |
| Initial Test Model `IsActive` | `TestModelState` | false (initial state only) |
| Simulation timestep (dt) | `TrainControllerRuntimeOptions.SimulationTimeStepSeconds` | 0.1 s |
| Speed multipliers | `TrainControllerRuntimeOptions.SupportedSpeedMultipliers` | 1×, 2×, 5×, 10× |
| Hardware request timeout | `HardwareLinkOptions.RequestTimeout` / appsettings `RequestTimeoutMs` | 200 ms |
| Hardware connect timeout | `HardwareLinkOptions.ConnectTimeout` / `ConnectTimeoutMs` | 500 ms |
| Hardware reconnect interval | `HardwareLinkOptions.ReconnectInterval` / `ReconnectIntervalMs` | 2 s |
| Pi endpoint | `HardwareLinkOptions.Host` / `Port` (appsettings.json; `--pi-host` / `--pi-port` per run) | appsettings: 192.168.50.2 : 5050 (team network); code default 127.0.0.1 : 5050 |

### Provisional design decisions (Phase 2)

Not specified by a project source. Rows marked **accepted** were reviewed and accepted as the
current provisional behavior; all remain changeable in one place.

| Behavior | Status | Where |
| -------- | ------ | ----- |
| Track signal lost → immediate service-brake stop (setpoint 0, held once stopped); latched Signal Pickup Failure after 0.5 s. (Replaces the earlier configurable `TrackSignalLossResponse` and the earlier "no timeout inference" decision.) | accepted | `SoftwareTrainController`, `FailureMonitor` |
| Stopped and not ready to depart (target ≈ 0, or doors open / commanded open) → service brake held, preventing unintended motion | accepted | `SoftwareTrainController` step 8 |
| Doors: station logic opens the platform side in both modes; the driver may open either side while stopped in either mode, subject to the interlock. | accepted | `DoorController` |
| Driver E-brake reset (driver / passenger causes only) is allowed only when stopped and the passenger request is no longer active | accepted | `BrakeController` |
| Track signal invalid before any trusted authority → remaining authority 0 (held if stopped; authority emergency brake if moving) | accepted | `AuthorityTracker`, Pi `HardwareTrainController` |
| Switching into Manual clears the driver request (the train first follows the commanded speed); "Clear" returns to following it | accepted | `DriverInputState` |
| The train is a point; all distances (station, authority, brake points) are measured from the train's front. Train length is expected to be reflected in the beacon / authority distances supplied by Track Model | provisional — confirm with Track Model / Train Model | `GuidanceBar`, `SoftwareTrainController`, `HardwareTrainController` |
| Look-ahead of one control period (v·dt) in station/authority braking | provisional | discretization compensation, not a safety margin |
| Overspeed brakes only above limit + 0.45 m/s (~1 mph) and keeps braking until back at the limit (hysteresis); `ControllerPolicy.OverspeedToleranceMetersPerSecond` | provisional | `OverspeedProtection`, Pi controller |
| Announcement events and wording ("Next station: X. …" on new beacon, "Arrived at X." on arrival; driver text takes precedence) | provisional | `SoftwareTrainController` |

**Startup gains: Kp = 100 000 W per (m/s), Ki = 10 000 W per (m/s·s)** (`EngineerSettings`).
First-estimate operating values: at about 15 m/s with the empty train they give a speed-error
time constant of roughly 6 s and an integral time of about 10 s. They are linearized estimates;
the Engineer can retune Kp/Ki per train at any time. The UI warns only if both gains are 0.
Behavior tests use explicitly named test-only gains and do not depend on these defaults.


## Normal mode: Train Model link and global tick clock (interim)

- **Inbound** (pipe `TrainControl.TrainController`): one `TrainModelStatusMessage` per active train per
  tick, tagged with `TickId`. The controller computes that train immediately and answers with a
  `TrainControllerCommandMessage` carrying the same `TickId` (same-tick pairing; the Train Model
  applies it in the next tick). Door and light states are no longer sent by the Train Model: they
  follow the controller's commands (no door / light failures are modelled), so the last commanded
  states are used as the actual ones (Test UI shows them read-only).
- **Until event flags are agreed**, a new authority is inferred from the first value, a changed value
  or the track signal becoming valid again; a new beacon from a changed station name or distance.
- **Global tick clock**: `TrainControl.SystemClock.TickClockCoordinator`, in its own shared project
  (`src/Shared/TrainControl.SystemClock`, so `TrainControl.Common` stays independent of the contracts). This process hosts it for now (`appsettings.json` → `Clock.Host = true`, participants
  `TrainControl.TrainModel`). Messages: `TickMessage`, `TickDoneMessage`, `ClockControlMessage`
  (Run / Pause / Step / SetSpeed / Reset), `ClockStateMessage`, `ResetMessage`, `ResetDoneMessage`.
  The next tick starts only after every participant's `TickDone`; a participant that does not answer
  within `TickTimeoutMilliseconds` stops the clock with a fault. Reset waits for every `ResetDone`
  and restarts from tick 1. When CTC hosts the clock, set `Clock.Host = false` (`HostPipe` = CTC):
  this process then only answers `Tick` / `Reset` as a participant.
- With Test Mode off, the Test UI's Run / Stop / Step / Reset / speed controls drive the global
  clock; with Test Mode on they drive the local test simulation as before.
