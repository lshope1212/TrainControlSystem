﻿# Views

Future `UserControl` views for the Train Model application go here, for example:

- `TrainStatusView.xaml`
- `TrainControlsView.xaml`
- `FailureControlsView.xaml`

The single application window is `MainWindow.xaml` in the project root — do **not**
add another `MainWindow.xaml` here.
