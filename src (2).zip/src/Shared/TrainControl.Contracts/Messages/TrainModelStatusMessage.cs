using TrainControl.Contracts.Enums;

namespace TrainControl.Contracts.Messages;

/// <summary>
/// State of one train as seen by its on-board Train Controller.
/// Direction: Train Model -> Train Controller.
/// </summary>
/// <remarks>
/// <para>
/// PROPOSED contract: the Train Model interface does not define these fields yet. All values
/// are SI. The Train Model does not know (and must not know) whether the train is driven by
/// the Software or the Hardware Train Controller.
/// </para>
/// <para>
/// <see cref="CommandedSpeedMetersPerSecond"/> and <see cref="CommandedAuthorityMeters"/>
/// are the values the wayside has authorized, relayed to the train through the track.
/// The Train Controller never reads the track-layout workbook itself.
/// </para>
/// <para>
/// Beacon fields describe the most recently received beacon. How the Train Model signals that
/// a beacon has JUST been received (a separate event, a one-tick flag, ...) is not yet defined
/// by the Train Model interface, so this contract deliberately imposes no event identifier.
/// Detecting a new reception is the Train Controller input adapter's job once that mechanism
/// is agreed; every newly received valid beacon must recalibrate station distance.
/// </para>
/// </remarks>
public class TrainModelStatusMessage
{
    public string TrainId { get; set; } = string.Empty;

    /// <summary>Tick this state belongs to (state at the END of the tick); the controller answers
    /// with commands tagged with the same TickId. Door and light states are NOT sent: doors and
    /// lights always follow the controller's commands (no door / light failures are modelled).</summary>
    public long TickId { get; set; }

    /// <summary>
    /// True while the overall system has dispatched the train (CTC -> Track Controller ->
    /// Train Model) and it is in service. Owned by the Train Model / system, never by the
    /// Train Controller, which only executes controller ticks for active trains.
    /// </summary>
    public bool IsActive { get; set; }

    public double ActualSpeedMetersPerSecond { get; set; }

    public double CommandedSpeedMetersPerSecond { get; set; }

    /// <summary>Commanded authority as ISSUED by the wayside and relayed unchanged by the
    /// Train Model (measured from the current block's start). The Train Model does NOT compute
    /// remaining authority; the Train Controller derives remaining from this plus integrated
    /// actual speed. (Contract change: formerly RemainingAuthorityMeters.)</summary>
    public double CommandedAuthorityMeters { get; set; }

    /// <summary>False when the track-circuit speed/authority signal is lost or invalid.</summary>
    public bool TrackSignalValid { get; set; }

    /// <summary>
    /// Traffic light (wayside signal aspect) ahead of the train, as provided by the Track Model.
    /// PROVISIONAL field until the final Track Model contract is agreed. Display-only in the
    /// Train Controller; independent of <see cref="TrackSignalValid"/>.
    /// </summary>
    public SignalState TrafficLight { get; set; } = SignalState.Unknown;

    /// <summary>True when the beacon fields below carry valid data.</summary>
    public bool BeaconValid { get; set; }

    /// <summary>
    /// Increments each time the train reads a NEW beacon (a new pass, even of the same station);
    /// the Train Controller recalibrates its station distance when it changes. 0 = not provided
    /// (the controller then falls back to detecting a changed station name or distance).
    /// </summary>
    public long BeaconSequence { get; set; }

    public string NextStationName { get; set; } = string.Empty;

    /// <summary>Distance from the beacon to the next station, at the moment the beacon was read.</summary>
    public double DistanceToNextStationMeters { get; set; }

    // Fully qualified: BeaconMessage.cs also declares a PlatformSide (without Both) in this
    // namespace, which would otherwise take precedence over the shared Enums type.
    public Enums.PlatformSide PlatformSide { get; set; } = Enums.PlatformSide.None;

    public bool PassengerEmergencyBrakeRequested { get; set; }

    public double CabinTemperatureCelsius { get; set; }
}
